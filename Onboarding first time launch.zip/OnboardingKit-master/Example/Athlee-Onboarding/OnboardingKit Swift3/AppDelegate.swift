//
//  AppDelegate.swift
//  OnboardingKit Swift3
//
//  Created by mac on 18/09/16.
//  Copyright © 2016 Athlee. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        let defaults = UserDefaults.standard
        let skipTutorialPages = defaults.bool(forKey: "skipTutorialPages")
        
        if skipTutorialPages
        {
            let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            
            let nextView: TheNextViewController = mainStoryboard.instantiateViewController(withIdentifier: "TheNextViewController") as! TheNextViewController
            
            window?.rootViewController = nextView
            
        } else {
          //  UIPageControl.appearance().pageIndicatorTintColor = UIColor.lightGray
           // UIPageControl.appearance().currentPageIndicatorTintColor = UIColor.red
        }
        
        
        
        return true
    }
}

